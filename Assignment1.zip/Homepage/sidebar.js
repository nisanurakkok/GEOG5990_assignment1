/* Set the width of the sidebar to show it */
function openNav() {
  document.getElementById("mySidepanel").style.width = "250px";
}

/* Set the width of the sidebar to hide it */
function closeNav() {
  document.getElementById("mySidepanel").style.width = "0";
}